class HomeController < ApplicationController

  before_filter :set_objects
  before_filter :set_breadcrumbs

  def index
    @item_type = get_item_type
    @search = params[:search]
    if @search.present?
      @items = Item.basic_search(@search).page(@pagenr)
    else
      @items = @category ?
        Item.for_type(get_item_type).where(category_id: @category.self_and_descendants).ordered.paginate(page: @pagenr, per_page: @per_page) :
        Item.for_type(get_item_type).ordered.page(@pagenr)
    end
  end

  def get_add_class
    # "no-padding-left"
  end

private

  def set_objects
    @category = params[:category_id] ? Category.find(params[:category_id]) : nil
    @tree = @category ? @category.self_and_ancestors.visible : []
  end

end
