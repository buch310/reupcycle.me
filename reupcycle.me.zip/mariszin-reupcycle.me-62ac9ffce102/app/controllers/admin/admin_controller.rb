class Admin::AdminController < ApplicationController

  layout "user"
  respond_to :html

  inherit_resources
  include Resources

  before_filter :authenticate_admin!
  load_and_authorize_resource

  def show_categories?
    false
  end

  def left_menu_bar
    "user_left_menu"
  end

end
