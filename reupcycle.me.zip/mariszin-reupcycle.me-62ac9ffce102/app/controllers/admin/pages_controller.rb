class Admin::PagesController < Admin::AdminController

  defaults resource_class: Page, collection_name: 'pages', instance_name: 'page'

  def permitted_params
    params.permit(page: [:slug, :title, :body])
  end

end
