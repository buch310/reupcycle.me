class Admin::CurrenciesController < Admin::AdminController

  defaults resource_class: Currency, collection_name: 'currencies', instance_name: 'currency'

  def permitted_params
    params.permit(currency: [:code, :name, :symbol])
  end

end
