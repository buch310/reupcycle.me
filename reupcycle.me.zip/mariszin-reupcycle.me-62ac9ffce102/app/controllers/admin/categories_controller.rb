class Admin::CategoriesController < Admin::AdminController

  defaults resource_class: Category, collection_name: 'categories', instance_name: 'category'

  def move_up
    resource.move_left
    resource.save!
    redirect_to collection_path
  end

  def move_down
    resource.move_right
    resource.save!
    redirect_to collection_path
  end

  private

  def permitted_params
    params.permit(category: [:title, :description, :visible, :placeholder, :slug, :parent_id])
  end

end
