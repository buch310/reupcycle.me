class Admin::CountriesController < Admin::AdminController

  defaults resource_class: Country, collection_name: 'countries', instance_name: 'country'

  def permitted_params
    params.permit(country: [:code, :name])
  end

end
