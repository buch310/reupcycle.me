class Admin::CitiesController < Admin::AdminController

  defaults resource_class: City, collection_name: 'cities', instance_name: 'city'

  private
  
  def permitted_params
    params.permit(city: [:country_id, :name])
  end

end
