class ApplicationController < ActionController::Base
  protect_from_forgery

  respond_to :html

  layout "application"

  before_action :set_locale
  before_action :set_pagination

  after_action :user_activity

  before_filter :configure_permitted_parameters, if: :devise_controller?

  helper_method :show_categories?, :return_location, :get_add_class, :left_menu_bar

  protected

  def configure_permitted_parameters
    devise_parameter_sanitizer.for(:sign_up) { |u| u.permit(:name, :email, :password, :country, :country_id, :city) }
  end

  private

  def user_activity
    current_user.try(:touch) if user_signed_in? && current_user.updated_at <= 9.minutes.ago
  end

  def store_location
    if request.get? && request.format.html? && !request.xhr? &&
      !devise_controller? && request.fullpath != new_user_session_path
      session[:user_return_to] = request.fullpath
    end
  end

  def authenticate_admin!
    if user_signed_in?
      if !current_user.is_admin
        redirect_to home_path
      else
        redirect_to home_path
      end
    else
      store_location
      redirect_to new_user_session_path
    end
  end

  def authenticate_user!
    if !user_signed_in?
      store_location
      redirect_to new_user_session_path
    end
  end

  def set_locale
    if params[:locale] && I18n.available_locales.include?(params[:locale].to_sym)
      I18n.locale = params[:locale].to_sym
    else
      I18n.locale = Settings.default_locale.to_sym
    end
  end

  def default_url_options(options={})
    { locale: I18n.locale }
  end

  def set_pagination
    @pagenr = params[:page] || 1
    @per_page = params[:per_page] || Settings.will_paginate.per_page
  end

  def set_breadcrumbs
    if @category
      add_breadcrumb(t(:start), home_path)
      add_breadcrumb(@category.parent.title, category_path(@category.parent)) if @category.parent.present?
      add_breadcrumb(@category.title, category_path(@category))
    end
    add_breadcrumb(@item.title, item_path(@item)) if @item
    true
  end

  def show_categories?
    true
  end

  def return_location default = home_path
    session.delete(:user_return_to) || default
  end

  def get_item_type other = nil
    return unless params.has_key?(:item_type)
    it = params[:item_type]
    Item::TYPES.include?(it) ? it : other
  end

  def get_add_class
    ""
  end

  def left_menu_bar
    "category_links"
  end

end
