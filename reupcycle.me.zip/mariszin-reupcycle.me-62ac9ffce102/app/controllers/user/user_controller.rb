class User::UserController < ApplicationController
  
  layout "user"
  respond_to :html

  before_filter :authenticate_user!
  load_and_authorize_resource except: :remove_item

  def show_categories?
    false
  end

  def left_menu_bar
    "user_left_menu"
  end

end
