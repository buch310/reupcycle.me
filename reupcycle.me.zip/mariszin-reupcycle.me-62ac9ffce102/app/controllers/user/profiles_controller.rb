class User::ProfilesController < User::UserController

  skip_load_and_authorize_resource

  def edit
    @user = current_user
    @user.build_asset unless @user.asset.present?
  end

  def update
    params[:user].delete(:current_password)
          
    @user = User.find(current_user.id)
    if @user.update_without_password(user_params)
      sign_in :user, @user, bypass: true
      redirect_to user_items_path, notice: t("profile.updated")
    else
      @user.clean_up_passwords
      respond_with @user
    end
  end

  def change_password
    @user = current_user
  end

  def update_password
    @user = User.find(current_user.id)

    if @user.update_with_password(user_params)
      sign_in :user, @user, bypass: true
      redirect_to home_path, notice: t("profile.password_changed")
    else
      @user.clean_up_passwords
      respond_with @user
    end
  end

private

  def user_params
    params.require(:user).permit(:name, :email, :country_id, :city, :password, :password_confirmation, :current_password, asset_attributes: [:id, :image])
  end

end
