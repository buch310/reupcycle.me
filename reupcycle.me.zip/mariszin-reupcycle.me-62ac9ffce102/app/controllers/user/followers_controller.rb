class User::FollowersController < User::UserController

  skip_load_and_authorize_resource

  def index
    @followers = current_user.followers
    @following = current_user.following
  end

end
