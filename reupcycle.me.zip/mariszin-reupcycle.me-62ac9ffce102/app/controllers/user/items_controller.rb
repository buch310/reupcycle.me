class User::ItemsController < User::UserController

  inherit_resources
  include Resources

  def index
    @items = current_user.items.paginate(page: params[:page], per_page: params[:per_page])
  end

  def new
    session[:referer] = request.referer if params[:return]

    resource.country = current_user.country if current_user.country
    resource.city = current_user.city if current_user.city
    resource.item_type = get_item_type
    if params[:category]
      if cat = Category.find(params[:category]) rescue nil
        if cat.leaf?
          resource.category = cat
        else
          resource.category = cat.children.first
        end
      end
    end
    Item::MAX_IMAGES.times { resource.assets.build }
  end

  def edit
    (Item::MAX_IMAGES - resource.assets.count).times { resource.assets.build }
  end

  def create
    if resource.save
      if session[:referer]
        ref = session.delete(:referer)
        redirect_to ref
      else
        redirect_to edit_resource_path, notice: 'Item was successfully created.'
      end
    else
      (Item::MAX_IMAGES - resource.assets.count).times { resource.assets.build }
      render action: "new"
    end
  end

  def update
    if resource.update_attributes(item_params)
      redirect_to edit_resource_path, notice: 'Item was successfully updated.'
    else
      (Item::MAX_IMAGES - resource.assets.count).times { resource.assets.build }
      render action: "edit"
    end
  end

  def close
    resource.update_attribute :active, false
    redirect_to user_items_path, notice: "Item was successfully closed."
  end

  def open
    resource.update_attribute :active, true
    redirect_to user_items_path, notice: "Item was successfully opened."
  end

  def offer
    render layout: "application"
  end

  def make_offer
    @item = Item.find(params[:id].to_i)
    if @item.user == current_user
      return redirect_to item_path(@item), notice: "You can't make an offer to your own items!"
    end
    if @item.item_type == Item::TYPE_SWOP
      if params[:offered_id].to_i == 0
        return redirect_to offer_user_item_path(@item), notice: "You must select an item to offer!"
      end
      @offered_item = Item.find(params[:offered_id].to_i)
      if @offered_item.user != current_user
        return redirect_to item_path(@item), notice: "You can't offer an item that is not yours!"
      end
    end

    offer = Offer.create! owner: @item.user, item: @item, offerer: current_user, offered: @offered_item
    message = offer.messages.create!(receiver_id: offer.owner == current_user ? offer.offerer.id : offer.owner.id, user_id: current_user.id, message: params[:message])
    redirect_to @item, notice: "Your offer has been sent."
  end

  protected

    def begin_of_association_chain
      current_user
    end

  private

  def item_params
    params.require(:item).permit(:category_id, :title, :description, :open_to_offer, :i_want, :location_text,
    :active, :type, :item_type, :valid_until, :price, :currency_id,
    :country_id, :city, :more_info_link, :show_location, :phone, assets_attributes: [:id, :image])
  end

end
