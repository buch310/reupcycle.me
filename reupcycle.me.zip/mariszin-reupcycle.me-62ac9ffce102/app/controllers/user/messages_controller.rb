class User::MessagesController < User::UserController

  skip_load_and_authorize_resource

  # inherit_resources

  skip_authorize_resource
  # defaults resource_class: Mailboxer::Conversation, collection_name: 'conversations', instance_name: 'conversation'

  after_action :mark_as_read, only: :show

  def index
    if params[:t]=="d" || !params[:t].present?
      @offers = current_user.inbox
    elsif params[:t]=="r"
      @offers = current_user.received_msgs
    elsif params[:t]=="s"
      @offers = current_user.sent_msgs
    end
  end

  def show
    @offer = Offer.find_by_id params[:id]
    @messages = @offer.active_messages.active(current_user,@offer).desc
    @offer.item_messages.read_all(current_user)
  end

  # def show
  #   # return redirect_to(user_messages_path, alert: "You can't have sent or received messages from yourself!") if current_user.id == params[:id].to_i
  #   # unread = @messages.where(user_has_read: false, receiver_id: current_user.id)
  #   # unread.each {|m| m.update_attribute :user_has_read, true }
  #   # @message = Message.new user: current_user, receiver: @user
  # end

  # def destroy
  #   # authorize! :delete, @messages.first
  #   # @messages.destroy_all
  #   # redirect_to(user_messages_path, notice: t("messages.deleted"))
  # end

  def delete_message
    offers = Offer.where(id: params[:offer_ids][0].split(','))
    offers.each do |o|
      if o.owner_id == current_user.id
        o.item_messages.each do |im|
          im.update_attributes(deleted_by_owner: true)
        end
      elsif o.offerer_id == current_user.id
        o.item_messages.each do |im|
          im.update_attributes(deleted_by_offerer: true)
        end
      end
    end

    # if params[:t]=="offer"  
      # receipt = ItemMessage.find_by_id(params[:id])
    # else
    #   receipt = current_user.mailbox.receipts.collect(&:message).find(params[:id])
    # end
    # receipt.destroy if receipt.present?
    redirect_to user_messages_path
  end

  def destroy
    message = ItemMessage.find(params[:id])
    if message.offer.owner_id == current_user.id
      message.update_attributes(deleted_by_owner: true)
    elsif message.offer.offerer_id == current_user.id
      message.update_attributes(deleted_by_offerer: true)
    end
    redirect_to :back
  end

  def create
    create! do |format|
      if resource.errors.empty?
        format.html { redirect_to user_message_path(resource.receiver) }
      else
        format.html { render :show }
      end
    end
  end

  def send_message
    offer = Offer.find params[:id]
    to_id = offer.owner_id==current_user.id ? offer.offerer_id : offer.owner_id
    message = offer.item_messages.create(message: params[:message], from_id: current_user.id, to_id: to_id)
    message.notifications.create(from_id: offer.offerer_id, to_id: offer.owner_id)
    @messages = offer.active_messages.desc
    # current_user.reply_to_conversation(resource, params[:message])
    # @messages = if params[:last_id]
    #   resource.messages.where("id > ?", params[:last_id])
    # else
    #   [resource.messages.last]
    # end
    # respond_to do |format|
    #   format.html { redirect_to user_message_path(resource) }
    #   format.js
    # end
  end

private

  def mark_as_read
    @offer = Offer.find_by_id params[:id]
    if @offer
      @offer.unread_messages.each do |m|
        m.mark_as_read
      end
    end
    # resource.receipts_for(current_user).each do |r|
    #   puts "got receipt:", r
    #   r.mark_as_read
    # end
  end

end
