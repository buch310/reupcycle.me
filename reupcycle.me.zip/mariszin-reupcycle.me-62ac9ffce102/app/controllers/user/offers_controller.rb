class User::OffersController < User::UserController

  inherit_resources
  include Resources
  load_and_authorize_resource except: :remove_item



  def index
    p params[:t]
    @offers = if params[:t] == "s"
                Offer.sent_offer(current_user).desc
              elsif params[:t] == "p"
                p "inside pending_offer"
                pending = Offer.pending_offer(current_user)
                receiving = Offer.received_offer(current_user).desc
                pending_offers = pending + receiving
              elsif params[:t] == "c"
                Offer.completed_offer(current_user).desc
              else
                Offer.received_offer(current_user).desc
              end
    respond_to do |format|
      format.js
      format.html
    end
    p "*****************************"
    p @offers
    p "*****************************"
  end

  def detail
    @received_offers = Offer.received_offer(current_user)
    @offer.read!
    @offer.item_messages.read_all(current_user)
  end

  def update_status
    if params[:status]=="item_received"
      if params[:t]=="r"
        @offer.update_attributes(owner_received: true, owner_pending: false, accepted: true, offerer_swap_pending: true, owner_swap_pending: true)
      elsif params[:t]=="p"

        @offer.update_attributes(owner_received: true)
        @offer.offerer_swap_pending = true if @offer.offerer_id==current_user.id
        @offer.owner_swap_pending = true if @offer.owner_id==current_user.id
        @offer.save
      end
      if @offer.item.swap? and @offer.can_swap?
        item = @offer.item
        swap = @offer.swap
        @offer.update_attributes(accepted: true)
        item.update_attributes(user_id: @offer.offerer_id)
        swap.update_attributes(user_id: @offer.owner_id)
      end
    else
      @offer.update_attributes(owner_received: false, owner_pending: true)
    end
    render json: {data: @offer}
  end

  def new
    @item = Item.find(params[:item_id])
    @offer = Offer.new item: @item, offerer: current_user, owner: @item.user, message: "Swop me!"
  end

  def create
    p "*****************************"
    p resource
    p "***************************"
    resource.owner = resource.item.user
    resource.offerer = current_user
    create! do |format|
      if resource.errors.empty?
        # format.html { redirect_to user_message_path(resource.mailbox.conversations.first) }
        format.html { redirect_to resource.item.sell? ? user_messages_path : user_offers_path }
      end
    end
  end

  def show
    resource.update_attribute(:user_has_read, true) if resource.owner_id == current_user.id
    redirect_to user_message_path(resource.mailbox.conversations.first)
  end

  def accept
    if resource.item.swap?
      resource.update_attributes(owner_received: false, owner_pending: true)
    else
      resource.update_attributes(accepted: true)
    end
    # resource.update_attribute :accepted, true
    # if resource.item.swap?
    #   p item = resource.item
    #   p swap = resource.swap
    #   item.update_attributes(user_id: resource.offerer_id)
    #   swap.update_attributes(user_id: resource.owner_id)
    # end
    redirect_to user_offers_path, notice: t("offer.accepted")
  end

  def reject
    resource.update_attribute :rejected, true
    # resource.destroy!
    redirect_to user_offers_path, notice: t("offer.rejected")
  end

  def destroy_messages
    @offer.active_messages.destroy_all
    redirect_to :back
  end

  def received
    if resource.owner == current_user
      resource.update_attribute :owner_received, true
    elsif resource.offerer == current_user
      resource.update_attribute :offerer_received, true
    else
      return redirect_to user_offers_path, alert: "You are not the receiver or the sender of the offer!"
    end
    if resource.owner_received && resource.offerer_received
      owner_id = resource.owner_id
      offerer_id = resource.offerer_id
      resource.item.update_attributes user_id: offerer_id, active: false
      if resource.offered
        resource.offered.update_attributes user_id: owner_id, active: false
      end
      resource.delete
      redirect_to user_offers_path, notice: "Offer is now complete"
    else
      redirect_to [:user, offer], notice: "Item marked as received."
    end
  end

  def create_message
    message = resource.item_messages.build
    message.message = params[:offer][:message]
    message.from_id = current_user.id
    message.to_id = (current_user.id==resource.offerer_id ? resource.owner_id : resource.offerer_id)
    message.save
    message.notifications.create(from_id: current_user.id, to_id: message.to_id)
    if params[:page]=="show_all"
      @page_name = "show_all"
      @messages = @offer.all_messages
    else
      @page_name = "confirm_page"
      @messages = @offer.latest_messages
    end
  end

  def remove_item
    if params[:type] == "sent"
      offer = Offer.find_by_item_id(params[:item_id])
      offer.is_active = false
      offer.save
      render json: {data: "Item removed from sent offers"}
    else
      offer = Offer.find_by_item_id(params[:item_id])
      if current_user == offer.owner
        offer.is_owner_completed = false
      else
        offer.is_offerer_completed = false
      end
      offer.save
      render json: {data: "Item removed from complete offers"}
    end
  end

private

  def permitted_params
    params.permit(offer: [:item_id, :offered_id, :message, :swap_id])
  end

end
