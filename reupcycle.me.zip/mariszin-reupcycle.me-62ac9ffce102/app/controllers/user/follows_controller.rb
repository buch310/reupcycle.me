class User::FollowsController < User::UserController

  respond_to :json

  skip_load_and_authorize_resource

  def follow
    f = Follower.find_or_initialize_by(who_id: current_user.id, follow_id: params[:id])
    if f.new_record?
      f.save
    else
      f.delete
    end
    respond_to do |f|
      f.json { render json: { count: Follower.where(follow_id: params[:id]).count } }
    end
  end

end
