class ItemsController < ApplicationController

  before_filter :store_location, only: :show
  before_filter :set_objects
  before_filter :set_breadcrumbs

  def show
    @other = @item.user.items.where("id!=?", @item.id).limit(6)
    @title = @item.title_str
    render layout: !request.xhr?
  end

  def set_objects
    @item = Item.find(params[:id].to_i)
    @category = @item.category
    @tree = @category ? @category.self_and_ancestors.visible : []
  end

  def get_add_class
  end

end
