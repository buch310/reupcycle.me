class PagesController < ApplicationController

  def show
    @page = Page.find_by_slug(params[:id])
    @title = @page.title
  end

  def contact
    @title = I18n.t("contact-us")
  end

  def send_message
    if user_signed_in?
      name = current_user.name
      email = current_user.email
    else
      name = params[:name]
      email = params[:email]
      if name == nil || name.blank?
        return render action: :contact, alert: "You must enter Your name!"
      elsif email == nil || email.blank?
        return render action: :contact, alert: "You must enter Your email!"
      end
    end
    message = params[:message]
    if message == nil || message.blank?
      return render action: :contact, alert: "You must enter a message to send!"
    end

    ContactsMailer.contact_us(name, email, message).deliver_now

    redirect_to contact_us_path, notice: "Message sent. We will try to respond as soon as we can."
  end

end
