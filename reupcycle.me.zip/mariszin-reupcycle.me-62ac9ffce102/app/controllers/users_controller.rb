class UsersController < ApplicationController
  
  def show
    @user = params[:id] ? User.find(params[:id].to_i) : current_user
    @items = @user.items
    # @messages = current_user.messages_received(@user) if user_signed_in? && current_user != @user
  end

end
