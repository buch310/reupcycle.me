class ContactsMailer < ActionMailer::Base
  include TranslationsHelper

  default from: "info@reupcycle.me"
  default to: "reupcycle.me@gmail.com"

  def contact_us(name, mail, message)
    @name = name
    @mail = mail
    @message = message
    mail(subject: t("contact_us.subject", name: @name, mail: @mail))
  end

end
