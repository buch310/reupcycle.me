module ApplicationHelper

  def default_country
    Country.find_by_code(Settings.default_country)
  end

  def app_logo_path
    "logo_#{request.domain}.png"
  end

  def check_swap_or_not(offer)
    offer.item && offer.swap ? "modal-lg" : "modal-wide"
  end

  def active?(t, current)
    (t==current) ? "hightlight_border" : ""
  end

end
