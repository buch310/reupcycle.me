module ButtonHelper

  def delete_button path, confirm = nil
    confirm ||= t("confirm")
    link_to path, data: { confirm: confirm}, method: :delete, class: "delete" do
      haml_tag :b, class: "icon-remove"
    end
  end

end
