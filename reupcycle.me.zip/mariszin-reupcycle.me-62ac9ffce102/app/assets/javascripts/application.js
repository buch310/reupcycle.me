//= require jquery
//= require jquery_ujs
//= require jquery-ui
//= require jquery.easing
//= require jquery.placeholder.min
//= require jquery.smooth-scroll.min
//= require jquery.colorbox
//= require app
//= require twitter/bootstrap


$(document).ready(function(){

  $(".delete_all_checkbox").change(function(){
    var value = $(this).is(':checked');
    if(value){
      $(".delete_checkbox").prop('checked', true);
    }else{
      $(".delete_checkbox").prop('checked', false);
    }
  });

  // $(document).on("click", ".offer_menu a", function(){
  //   $(".offer_menu a").removeClass("highlight");
  //   $(this).addClass("highlight");
  // });

  $(document).on("click", ".update_offer_status", function(){
    if($(".offer_status_inp:checked").val()=="" || $(".offer_status_inp:checked").val()==undefined){
      alert("Please select any option");
      return false;
    }
    if(!confirm("Are you sure?")){
      return false;
    }
    console.log("update offer status method called");
    console.log($(this).data("offer_status_url"));
    $.ajax({
      url: $(this).data("offer_status_url"),
      data: {status: $(".offer_status_inp:checked").val()},
      method: "post",
      success: function(){
        console.log("offer status updated");
        location.reload();
      }
    });
  });

  $(".delete_all_checkbox_link").click(function(){
    if(!confirm("Are you sure?")){
      return false;
    }
    var val = [];
    $('.offer_status_inp:checked').each(function(i){
      val[i] = $(this).val();
    });

    $.ajax({
      url: $(this).attr("href"),
      data: {offers: val},
      method: "post",
      success: function(){
        console.log("delete updated");
      }
    });
  });

  $(".offer-form").submit(function(){
    console.log("Offer form submitting...");
    if($("#offer_swap_id").length>0){
      if($("#offer_swap_id").val()==""){
        alert("Please select your item that you want to swap");
        return false;
      }
    }
    // $.ajax({
    //   url: $(this).data("offer_status_url"),
    //   data: {status: $(".offer_status_inp:checked").val()},
    //   method: "post",
    //   success: function(){
    //     console.log("offer status updated");
    //   }
    // });
  });

  $(document).on('click', ".delete_selected_message, .delete_all_checkbox_link", function(e){
    $("#delete_message").submit();
  });

  $(document).on('change', '.delete_checkbox, .delete_all_checkbox', function(){
    var box = $("[class='delete_checkbox']:checked");
    var delete_all = $(".delete_all_checkbox").is(':checked');
    var offer_id = [];
    $.each($("[class='delete_checkbox']:checked"), function(){ 
      offer_id.push(parseInt($(this).val()));
    });
    $("#offer_ids_").val(offer_id);
    if (box.length > 0 && !delete_all){
      $(".delete_selected_message").show();
    }
    else if (box.length == 0) {
      $(".delete_all_checkbox").prop('checked', false);
    }
    else {
      $(".delete_selected_message").hide();
    }
  });

  $(document).on("click", ".remove-item", function() {
    var id = $(this).data("id");
    console.log("remove-item")
    console.log($(this).data("id"));
    console.log($(this).attr("data-type"));
    $.ajax({
      url: "remove_item",
      type: "PUT",
      data: {item_id: id, type: $(this).attr("data-type")}
    }).done(function(data) {
      alert(data.data);
      location.reload();
    });
  });


});