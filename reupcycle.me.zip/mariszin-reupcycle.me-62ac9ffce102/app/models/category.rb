class Category < ActiveRecord::Base

  translates :title, :description, fallbacks_for_empty_translations: true

  acts_as_nested_set

  extend FriendlyId
  friendly_id :title, use: [:slugged, :finders]

  # has_many :items, dependent: :restrict_with_error
  has_many :items, dependent: :destroy
  
  validates :title, presence: true

  scope :visible, -> { where(visible: true) }

  after_initialize :init_values

  def to_s
    self.title
  end

  def self.rebuild!
    super
    self.update_all("#{depth_column_name} = ((select count(*) from #{self.quoted_table_name} t where t.lft <= #{self.quoted_table_name}.lft and t.rgt >= #{self.quoted_table_name}.rgt) - 1)")
  end

  def init_values
    self.visible = true if self.new_record?
  end

end
