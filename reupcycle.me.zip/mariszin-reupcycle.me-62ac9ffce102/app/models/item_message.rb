class ItemMessage < ActiveRecord::Base
  belongs_to :item
  belongs_to :from, class_name: "User", foreign_key: "from_id"
  belongs_to :to, class_name: "User", foreign_key: "to_id"
  belongs_to :offer
  has_many :notifications, as: :attachable

  def self.read_all(user)
    all.each do |im|
      im.unread_notifications.each do |n|
        n.mark_as_read
      end
    end
  end

  def unread_notifications
    notifications.where(read: false)
  end

  def mark_as_read
    self.active = true
    self.save
  end

  def self.desc
    order("created_at desc")
  end

  def self.active(user,offer)
    if offer.owner_id == user.id
      where(deleted_by_owner: false)
    elsif offer.offerer_id == user.id
      where(deleted_by_offerer: false)
    end
  end
end
