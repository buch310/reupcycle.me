class Page < ActiveRecord::Base

  translates :title, :body, fallbacks_for_empty_translations: true

  PAGE_ABOUT = 1
  PAGE_PRIVACY = 2
  PAGE_TERMS = 3

  PAGE_TYPE_INT = {
    "about-us" => PAGE_ABOUT,
    "privacy-policy" => PAGE_PRIVACY,
    "terms-of-use" => PAGE_TERMS
  }

  PAGE_TYPE_STR = {
    PAGE_ABOUT => "about-us",
    PAGE_PRIVACY => "privacy-policy",
    PAGE_TERMS => "terms-of-use"
  }

  validates :slug, :title, :body, presence: true
  validates :slug, uniqueness: true

end
