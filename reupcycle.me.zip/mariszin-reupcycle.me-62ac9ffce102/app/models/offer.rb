class Offer < ActiveRecord::Base

  acts_as_messageable

  belongs_to :owner, class_name: "User"
  belongs_to :offerer, class_name: "User"
  belongs_to :item, class_name: "Item"
  belongs_to :swap, class_name: "Item"
  belongs_to :offered, class_name: "Item"
  has_many :item_messages
  has_many :notifications, as: :attachable
  accepts_nested_attributes_for :item_messages, allow_destroy: true

  after_create :create_message

  attr_accessor :message

  validates :owner_id, :offerer_id, :item_id, presence: true
  # validates :offered_id, presence: true, if: -> { |o| o.try(:item).try(:item_type) == Item::TYPE_SWOP }

  scope :waiting, -> { where(accepted: false, rejected: false, canceled: false) }
  scope :in_progress, -> { where("accepted=? and (owner_received=? or offerer_received=?)", true, false, false) }

  def can_swap?
    offerer_swap_pending and owner_swap_pending
  end

  def accepted?
    "Offer Accepted by Owner #{owner.name}" if accepted
  end

  def rejected?
    "Offer Rejected by Owner #{owner.name}" if rejected
  end

  def unread_messages
    active_messages.where(read: false)
  end

  def read!
    self.user_has_read = true
    self.save
  end

  def active_messages
    item_messages.where(active: true)
  end

  def latest_messages
    item_messages.order("created_at desc")[0..1].reverse
  end

  def latest_active_messages(user)
    if self.owner_id == user.id
      item_messages.where.not(deleted_by_owner: true).order("created_at desc")[0..1].reverse
    elsif self.offerer_id == user.id
      item_messages.where.not(deleted_by_offerer: true).order("created_at desc")[0..1].reverse
    end
  end

  def all_messages
    item_messages.order("created_at desc").reverse
  end

  def self.received_offer(user)
    where(owner_id: user.id, accepted: [nil,false], rejected: [nil,false], owner_pending: [nil,false])
  end

  def self.sent_offer(user)
    # where(offerer_id: user.id, rejected: [nil,false])
    where(offerer_id: user.id).where(is_active: true)
  end

  def self.pending_offer(user)
    # where(accepted: [nil,false], rejected: [nil,false]).select{|offer| offer.offerer_id==user.id or (offer.item.user_id==user.id and offer.owner_pending)}
    where(accepted: [nil,false], rejected: [nil,false]).order("created_at desc").select{|offer| offer.offerer_id==user.id or (offer.item.user_id==user.id and offer.owner_pending and !offer.accepted)}
  end

  def self.completed_offer(user)
    where(accepted: true, rejected: [nil,false])#.where(is_completed: true)
  end

  def offerer_name
    offerer.try(:name)
  end

  def owner_name
    owner.try(:name)
  end

  def swap_item_title
    swap.try(:title)
  end

  def swap_item_desc
    swap.try(:description)
  end

  def item_title
    item.try(:title)
  end

  def self.desc
    order("created_at desc")
  end

  def item_desc
    item.try(:description)
  end

  def received_by user
    if self.owner == user && self.owner_received
      true
    elsif self.offerer == user && self.offerer_received
      true
    else
      false
    end
  end

  #Returning any kind of identification you want for the model
  def mailboxer_name
    return item.title
  end
  #Returning the email address of the model if an email should be sent for this object (Message or Notification).
  #If no mail has to be sent, return nil.
  def mailboxer_email(object)
    #Check if an email should be sent for that object
    #if true
    # return "define_email@on_your.model"
    #if false
    return nil
  end

  def create_message
    message = self.item_messages.build
    message.message = self.message
    message.from_id = self.offerer_id
    message.to_id = self.owner_id
    message.save

    message.notifications.create(from_id: self.offerer_id, to_id: self.owner_id)

    # if item.sell?
    #   offerer.send_message(owner, self.message, "Offer for " + self.item.title)
    # else
    #   self.send_message(self, self.message, "Offer for " + self.item.title)
    # end
  end

  def owner_message
    item_messages.where(from_id: offerer_id).last.try(:message)
  end

  def offer_owner_name
    @user_id = item_messages.where(from_id: offerer_id).last
    User.find_by_id(@user_id.from_id).try(:name)
  end

  def offer_receiver_name(user)
    @user = item_messages.where(from_id: user.id).last
    User.find_by_id(@user.from_id).try(:name)
  end

  def offer_receiver_message(user)
    item_messages.where(from_id: user.id).last.try(:message)
  end

end
