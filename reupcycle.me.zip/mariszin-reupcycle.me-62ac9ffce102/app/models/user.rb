class User < ActiveRecord::Base

  devise :database_authenticatable, :registerable, :recoverable, :rememberable, :trackable
  devise :omniauthable, :omniauth_providers => [:facebook]

  belongs_to :country
  has_many :item_messages, class_name: "ItemMessage", foreign_key: "to_id", dependent: :destroy
  has_many :notifications, class_name: "Notification", foreign_key: "to_id", dependent: :destroy
  has_one :asset, as: :object, dependent: :destroy
  has_many :items, dependent: :destroy
  has_many :outgoing_offers, class_name: "Offer", foreign_key: "offerer_id", dependent: :destroy
  has_many :incoming_offers, class_name: "Offer", foreign_key: "owner_id", dependent: :destroy
  has_many :following_link, class_name: "Follower", foreign_key: "follow_id"
  has_many :followers_link, class_name: "Follower", foreign_key: "who_id"
  has_many :followers, through: :following_link
  has_many :following, through: :followers_link
  # has_many :inbox, class_name: "ItemMessage", foreign_key: :to_id, dependent: :destroy

  accepts_nested_attributes_for :asset, allow_destroy: true

  acts_as_messageable

  validates :name, :email, :country_id, presence: true

  def unread_offer_count
    incoming_offers.where(user_has_read: [nil,false]).count
  end

  def unread_msg_count
    # msg1 = item_messages.joins(:offer).where("offers.owner_id = ? and item_messages.to_id = ?", id,id)
    # msg2 = item_messages.joins(:offer).where("offers.owner_id = ? and item_messages.to_id = ?", id,id)
    notifications.where(read: false).count
  end

  def inbox
    received = Offer.where(owner_id: id)
    sent = Offer.where(offerer_id: id)
    received + sent
  end

  def received_msgs
    received = Offer.where(owner_id: id)
  end

  def sent_msgs
    received = Offer.where(offerer_id: id)
  end

  def online?
    updated_at > 10.minutes.ago
  end

  def admin?
    is_admin
  end

  def active_swops
    Offer.where("owner_id=? or offerer_id=?", self, self).in_progress
  end

  # def unread_offer_count
  #   @unread_offer_count ||= Offer.where(owner_id: self.id, accepted: false).count
  #   p @unread_offer_count
  # end

  def received_offer_count
    received_offers = incoming_offers.joins(:item).where("items.item_type = ?", "swop")
    received_offers.count - received_offers.where(owner_id: self.id, accepted: true).uniq.count
  end

  def accept_offers
    incoming_offers.count - incoming_offers.where(owner_id: self.id, accepted: true).count
  end

  def follows? user
    Follower.where(who_id: id, follow_id: user.id).exists?
  end

  #Returning any kind of identification you want for the model
  def mailboxer_name
    return name
  end
  #Returning the email address of the model if an email should be sent for this object (Message or Notification).
  #If no mail has to be sent, return nil.
  def mailboxer_email(object)
    #Check if an email should be sent for that object
    #if true
    # return "define_email@on_your.model"
    #if false
    return nil
  end

  def self.find_for_facebook_oauth(access_token)
    data = access_token.extra.raw_info
    if user = User.where(email: data.email).first
      user
    else # Create a user with a stub password.
      user = User.create!(email: data.email, password: Devise.friendly_token[0,20], name: data.name)
    end
  end

  def self.new_with_session(params, session)
    super.tap do |user|
      if data = session["devise.facebook_data"] && session["devise.facebook_data"]["extra"]["user_hash"]
        user.email = data["email"]
      end
    end
  end

end
