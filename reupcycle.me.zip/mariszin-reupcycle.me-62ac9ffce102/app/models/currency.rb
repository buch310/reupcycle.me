class Currency < ActiveRecord::Base

  translates :name, fallbacks_for_empty_translations: true
  
  validates :code, :name, :symbol, :presence => true
  validates :code, :uniqueness => true

end
