class Country < ActiveRecord::Base

  translates :name, fallbacks_for_empty_translations: true
  
  has_many :cities

  validates :code, :name, presence: true

  scope :live, -> { all }

  def to_s
    self.name
  end

end
