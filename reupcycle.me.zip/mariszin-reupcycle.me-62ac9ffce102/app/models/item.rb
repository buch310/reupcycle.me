require 'uri'

class Item < ActiveRecord::Base

  TYPE_SWOP = "swop"
  TYPE_SALE = "sell"
  TYPE_BUY  = "buy"
  TYPE_FREE = "free"

  TYPES = [ TYPE_SWOP, TYPE_SALE, TYPE_FREE ]
  TYPES_HASH = TYPES.map { |t| [ I18n.t("type_form.#{t}"), t ] }
  LIMITS = {
    TYPE_SWOP => Settings.limits.for_swop,
    TYPE_SALE => Settings.limits.for_sale,
    TYPE_BUY => Settings.limits.for_buy,
    TYPE_FREE => Settings.limits.for_free
  }

  MAX_IMAGES = Settings.limits.images

  belongs_to :user
  belongs_to :category
  has_many :item_messages
  has_many :assets, as: :object, dependent: :destroy
  has_many :offers, class_name: "Offer", foreign_key: "item_id", dependent: :destroy
  has_one :offered_to, class_name: "Offer", foreign_key: "offered_id", dependent: :destroy
  belongs_to :currency
  belongs_to :country

  validates :item_type, :title, :description, :category, presence: true
  validates :price, presence: true, if: Proc.new { |i| i.item_type == Item::TYPE_SALE }
  validates :i_want, presence: true, if: Proc.new { |i| !i.open_to_offer and i.item_type == Item::TYPE_SWOP }
  validates :phone, format: { with: /\A\+?[0-9]+\z/ }, allow_blank: true
  # validates :item_type, in: TYPES
  validate :has_one_image
  validate :validate_more_info
  validate :limit_items

  accepts_nested_attributes_for :assets, allow_destroy: true

  scope :active, -> { where(active: true) }
  scope :swopable, -> { where(item_type: TYPE_SWOP) }
  scope :sellable, -> { where(item_type: TYPE_SALE) }
  scope :freebies, -> { where(item_type: TYPE_FREE) }
  scope :ordered, -> { order("created_at desc") }
  scope :for_type, ->(t) { Item::TYPES.include?(t) ? where(item_type: t) : self }

  before_save :set_more_info

  def sell?
    item_type=="sell"
  end

  def swap?
    item_type=="swop"
  end

  def self.types
    TYPES.map { |t| [ I18n.t("type_form.#{t}"), t ] }
  end

  def title_str
    "#{I18n.t("type.#{self.item_type}")}: #{self.title}"
  end

  def type_str
    [TYPE_SALE, TYPE_BUY].include?(self.item_type) ? "sale" : self.item_type
  end

private

  def has_one_image
    errors.add(:assets, "You must add at least #{Settings.item.min_images} image!") unless self.assets.select { |i| !i.marked_for_destruction? }.count >= Settings.item.min_images
    errors.any?
  end

  def validate_more_info
    @set_more_info = false
    return true unless more_info_link.present?
    begin
      uri = URI.parse(more_info_link)
      if uri.kind_of? URI::HTTP
        @set_more_info = ["www.apmainamies.lv", "www.swop-me.com"].include?(uri.host)
      else
        invalid_url = true
      end
    rescue URI::InvalidURIError
      invalid_url = true
    end
    errors.add(:more_info_link, I18n.t("errors.not_a_url")) if invalid_url
    errors.any?
  end

  def set_more_info
    self.more_info_local = @set_more_info
    true
  end

  def limit_items
    errors.add(:item_type, "limits sasniegts") if !self.id && self.user && self.user.items.for_type(self.item_type).where("id != ?", self.id).count >= LIMITS[self.item_type]
  end

end
