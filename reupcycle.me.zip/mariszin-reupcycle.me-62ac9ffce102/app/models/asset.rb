class Asset < ActiveRecord::Base

  belongs_to :object, polymorphic: true

  has_attached_file :image,
      styles: {
        thumb: "90x90#",
        small: "150x150#",
        medium: "400x400>",
        large: "800x600>"
      }

  # validates :item_id, presence: true
  validates_attachment :image,
    presence: true,
    content_type: { content_type: /\Aimage\/.*\Z/ },
    size: { in: 0..10.megabytes }

end
