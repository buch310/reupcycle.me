class City < ActiveRecord::Base

  translates :name, fallbacks_for_empty_translations: true
  
  belongs_to :country

  validates :country_id, :name, presence: true

end
