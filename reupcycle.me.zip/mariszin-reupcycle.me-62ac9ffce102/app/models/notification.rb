class Notification < ActiveRecord::Base
  belongs_to :attachable, polymorphic: true
  belongs_to :item_message

  def mark_as_read
    self.read = true
    self.save
  end

end
