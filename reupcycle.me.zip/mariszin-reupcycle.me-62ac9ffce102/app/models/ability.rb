class Ability
  include CanCan::Ability

  def initialize(user)
    user ||= User.new

    if user.admin?
      can :manage, Category
      can :manage, City
      can :manage, Country
      can :manage, Currency
      can :manage, Page
    end

    can :manage, Item, user_id: user.id

    # can :read, Message, receiver_id: user.id
    # can :read, Message, user_id: user.id
    # can :create, Message, user_id: user.id
    # cannot :create, Message, receiver: user.id
    # can :delete, Message, receiver_id: user.id
    # can :delete, Message, user_id: user.id

    can :create, Offer, offerer_id: user.id
    cannot :create, Offer, owner_id: user.id
    can :read, Offer, offerer_id: user.id
    can :read, Offer, owner_id: user.id
    can [:accept, :reject, :detail, :update_status, :create_message, :messages, :destroy_messages], Offer, owner_id: user.id
    can :received, Offer, owner_id: user.id
    can :received, Offer, offerer_id: user.id
    can :send_message, Offer #, owner_id: user.id
    # can :send_message, Offer, owner_id:
    can :reject, Offer, offerer_id: user.id
    can :detail, Offer, offerer_id: user.id
    can :create_message, Offer, offerer_id: user.id
    can :messages, Offer, offerer_id: user.id
    can :destroy_messages, Offer, offerer_id: user.id
    can :update_status, Offer, offerer_id: user.id

  end
end
