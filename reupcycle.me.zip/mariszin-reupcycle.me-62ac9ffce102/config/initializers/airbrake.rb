# Airbrake.configure do |config|
#   config.api_key = 'e14f4e991f52447a074647c3bf6c484e'
#   config.host    = 'errbit.swop-me.com'
#   config.port    = 80
#   config.secure  = config.port == 443
# end
