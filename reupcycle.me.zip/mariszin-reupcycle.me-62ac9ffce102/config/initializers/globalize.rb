Globalize.fallbacks = { 
  en: [:en, :lv, :ru], 
  lv: [:lv, :en, :ru],
  ru: [:ru, :en, :lv]
}