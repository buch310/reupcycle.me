Swopme::Application.routes.draw do

  devise_for :users, controllers: { omniauth_callbacks: "user/omniauth_callbacks", registrations: "registrations" }

  scope "/:locale", locale: /lv|ru|en/ do
    get  "/contact-us" => "pages#contact", as: :contact_us
    post "/contact-us" => "pages#send_message", as: :send_message

    get "/pages/:id" => "pages#show", as: :public_page
    get "/" => "home#index", as: :home
    get "/:category_id" => "home#index", as: :category

    namespace :admin do
      resources :categories do
        member do
          post :move_up
          post :move_down
        end
      end
      resources :pages
      resources :cities
      resources :countries
      resources :currencies
    end

    namespace :user do
      resource :profile, only: [:edit, :update] do
        get :change_password
        put :update_password
      end

      resources :items do
        member do
          post :close
          post :open
        end
      end

      resources :offers, only: [:index, :show, :new, :create] do
        member do
          post :accept
          post :reject
          post :received
          get :detail
          post :update_status
          post :create_message
          get :messages
          post :destroy_messages
        end
      end

      resources :messages, only: [:index, :show, :destroy] do
        get :delete_message, on: :collection
        member do
          post :send_message
        end
      end

      get "/followers" => "followers#index", as: :followers
    end

    resources :items, only: [:show]
    resources :users, only: [:show]
  end

  post "/follow/follow/:id", to: "user/follows#follow"

  match "*" => redirect("/#{Settings.default_locale}"), via: :any
  root to: redirect("/#{Settings.default_locale}")
end
