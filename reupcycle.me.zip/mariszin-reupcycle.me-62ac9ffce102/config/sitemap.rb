# Set the host name for URL creation
SitemapGenerator::Sitemap.default_host = "http://www.swop-me.com"
SitemapGenerator::Sitemap.include_root = false

SitemapGenerator::Sitemap.create do

  [:lv, :en, :ru].each do |locale|
    Category.visible.each do |cat|
      add category_path(cat, locale: locale), changefreq: "daily", priority: 0.8
    end

    Item.all.each do |item|
      add item_path(item, locale: locale), changefreq: "weekly", priority: 0.7
    end
  end
  
end
