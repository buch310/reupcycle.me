module Resources

  def create
    create! do |format|
      if resource.errors.empty?
        format.html { redirect_to collection_path }
      end
    end
  end

  def show
    redirect_to edit_resource_path
  end

  def update
    update!{ collection_path }
  end

end
