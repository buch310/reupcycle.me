require 'spec_helper'

describe Offer do

  context "validations" do
    it { should validate_presence_of(:owner_id) }
    it { should validate_presence_of(:offerer_id) }
    it { should validate_presence_of(:item_id) }

    it "should validate presence of offered_id if item.type == TYPE_SWOP" do
      o = FactoryGirl.build :offer, item: FactoryGirl.build(:item, :for_swop)
      expect(o).not_to be_valid
      expect(o).to have(1).error_on(:offered_id)
    end
  end

end
