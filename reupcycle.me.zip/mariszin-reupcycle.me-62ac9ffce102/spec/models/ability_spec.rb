require "spec_helper"

describe Ability do

  pending

end
