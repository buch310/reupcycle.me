require 'spec_helper'

describe Country do

  context "validations" do
    it { should validate_presence_of(:code) }
    it { should validate_presence_of(:name) }
  end
  
end
