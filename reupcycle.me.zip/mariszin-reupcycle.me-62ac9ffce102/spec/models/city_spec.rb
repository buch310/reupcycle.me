require 'spec_helper'

describe City do

  context "validations" do
    it { should validate_presence_of(:name) }
    it { should validate_presence_of(:country_id) }
  end

end
