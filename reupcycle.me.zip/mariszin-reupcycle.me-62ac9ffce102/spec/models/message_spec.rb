require 'spec_helper'

describe Message do

  context "validations" do
    it { should validate_presence_of(:user_id) }
    it { should validate_presence_of(:receiver_id) }
    it { should validate_presence_of(:message) }
  end

end
