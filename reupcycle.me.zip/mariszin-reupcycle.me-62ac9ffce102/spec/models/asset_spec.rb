require 'spec_helper'

describe Asset do

  context "validations" do
    it { should have_attached_file :image }
  end

end
