require 'spec_helper'

describe Item do

  context "validations" do
    it { should validate_presence_of(:item_type) }
    it { should validate_presence_of(:title) }
    it { should validate_presence_of(:description) }
    it { should validate_presence_of(:category) }

    it "should require price only on items for sale" do
      item = FactoryGirl.build :item, :for_sale, price: nil
      expect(item).not_to be_valid
      expect(item).to have(1).error_on(:price)
    end

    it "should require i_want only on items for swop" do
      item = FactoryGirl.build :item, :for_swop, i_want: nil, open_to_offer: false
      expect(item).not_to be_valid
      expect(item).to have(1).error_on(:i_want)
    end

    it "should not require i_wan on items for swop and open to offer" do
      item = FactoryGirl.build :item, :for_swop, i_want: nil, open_to_offer: true
      expect(item).to be_valid
      expect(item).not_to have(1).error_on(:i_want)
    end

    context "more_info" do
      let(:item) { FactoryGirl.build :item, more_info_link: nil, more_info_local: false }

      it "should not allow invalid more info link" do
        item.more_info_link = "javascript:alert('test')"
        expect(item).not_to be_valid
      end

      it "should set more_info_local to true for local domains" do
        item.more_info_link = "http://www.apmainamies.lv"
        expect(item.save).to be_true
        expect(item.more_info_local).to be_true
      end

      it "should set more_info_local to false for remote domains" do
        item.more_info_link = "http://www.apmainamies2.lv"
        expect(item.save).to be_true
        expect(item.more_info_local).to be_false
      end

    end
  end

end
