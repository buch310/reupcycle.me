require 'spec_helper'

feature Currency do

  context "unauthorised user" do
    scenario "should not be able to see admin menu" do
      visit home_path
      expect(page).not_to have_content t2(Currency)
    end
  end

  context "user" do
    before :each do
      @user = FactoryGirl.create :user
      login_as @user, scope: :user
    end

    scenario "should not be able to see admin menus" do
      visit home_path
      expect(page).not_to have_content t2(Currency)
    end
  end

  context "admin" do
    before :each do
      @user = FactoryGirl.create :user, :admin
      login_as @user, scope: :user
    end

    scenario "should be able to see admin menu" do
      visit home_path
      click_link t2(Currency)
      expect(current_path).to eq admin_currencies_path
    end

    scenario "should be able to create Currency" do
      expect(Currency.count).to eq 0
      visit admin_currencies_path

      click_link t("create")
      fill_in tt(Currency, :code), with: "LVL"
      fill_in tt(Currency, :name), with: "Lats"
      fill_in tt(Currency, :symbol), with: "Ls"
      click_button t("save")

      expect(Currency.count).to eq 1
      currency = Currency.last
      expect(current_path).to eq edit_admin_currency_path(currency)
      expect(currency.code).to eq "LVL"
      expect(currency.name).to eq "Lats"
      expect(currency.symbol).to eq "Ls"
    end

    scenario "should be able to delete Currency" do
      currency = FactoryGirl.create :currency

      expect(Currency.count).to eq 1
      visit admin_currencies_path

      expect(page).to have_content currency.name

      click_link t("delete")

      expect(Currency.count).to eq 0
    end
  end

end
