require 'spec_helper'

feature Country do

  context "unauthorised user" do
    scenario "should not be able to see admin menu" do
      visit home_path
      expect(page).not_to have_content t2(Country)
    end
  end

  context "user" do
    before :each do
      @user = FactoryGirl.create :user
      login_as @user, scope: :user
    end

    scenario "should not be able to see admin menus" do
      visit home_path
      expect(page).not_to have_content t2(Country)
    end
  end

  context "admin" do
    before :each do
      @user = FactoryGirl.create :user, :admin
      login_as @user, scope: :user
    end

    scenario "should be able to see admin menu" do
      visit home_path
      click_link t2(Country)
      expect(current_path).to eq admin_countries_path
    end

    scenario "should be able to create country" do
      expect(Country.count).to eq 1
      visit admin_countries_path

      click_link t("create")
      fill_in tt(Country, :code), with: "LV"
      fill_in tt(Country, :name), with: "Latvija"
      click_button t("save")

      expect(Country.count).to eq 2
      country = Country.last
      expect(current_path).to eq edit_admin_country_path(country)
      expect(country.code).to eq "LV"
      expect(country.name).to eq "Latvija"
    end

    scenario "should be able to delete country" do
      pending "should research how to select specific country"

      country = FactoryGirl.create :country

      expect(Country.count).to eq 1
      visit admin_categories_path

      expect(page).to have_content country.name

      click_link t("delete")

      expect(Country.count).to eq 0
    end
  end

end
