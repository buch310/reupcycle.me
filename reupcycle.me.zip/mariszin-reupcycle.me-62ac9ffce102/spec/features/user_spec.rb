require 'spec_helper'

feature User do

  context "unauthorised" do
  end

  context "user" do
    before :each do
      @user = FactoryGirl.create :user
      login_as @user, scope: :user
    end
  end

  context "admin" do
    before :each do
      @user = FactoryGirl.create :user, :admin
      login_as @user, scope: :user
    end
  end

end
