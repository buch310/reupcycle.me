require 'spec_helper'

feature Category do

  context "unauthorised user" do
    before(:each) do
      @c1 = FactoryGirl.create :category
      @c2 = FactoryGirl.create :category, parent: @c1
      @c3 = FactoryGirl.create :category
      @c4 = FactoryGirl.create :category, parent: @c3
      @c5 = FactoryGirl.create :category, parent: @c3, visible: false
    end

    scenario "should be able to see categories" do
      visit home_path
      expect(page).to have_content @c1.title
      # expect(page).to have_content @c2.title
      expect(page).to have_content @c3.title
      # expect(page).to have_content @c4.title
      # expect(page).not_to have_content @c5.title
    end

    scenario "should be able to see all items" do
      item1 = FactoryGirl.create :item, category: @c1

      visit home_path
      expect(page).to have_content item1.title
    end

    scenario "should be able to see items in specific category" do
      item1 = FactoryGirl.create :item, category: @c1
      item2 = FactoryGirl.create :item, category: @c2

      visit home_path
      click_link @c1.title
      expect(page).to have_content item1.title
      expect(page).to have_content item2.title

      # click_link @c2.title
      # expect(page).not_to have_content item1.title
      # expect(page).to have_content item2.title

      click_link @c3.title
      expect(page).not_to have_content item1.title
      expect(page).not_to have_content item2.title
    end
  end

  context "user" do
    before :each do
      @user = FactoryGirl.create :user
      login_as @user, scope: :user
    end

    scenario "should not be able to see admin menus" do
      visit home_path
      expect(page).not_to have_content t2(Category)
    end
  end

  context "admin" do
    before :each do
      @user = FactoryGirl.create :user, :admin
      login_as @user, scope: :user
    end

    scenario "should be able to see admin menu" do
      visit home_path
      click_link t2(Category)
      expect(current_path).to eq admin_categories_path
    end

    scenario "should be able to create category" do
      visit admin_categories_path
      expect(page).to have_content t("no_data")
      expect(Category.count).to eq 0

      click_link t("create")
      fill_in tt(Category, :title), with: "Category test"
      click_button t("save")

      expect(Category.count).to eq 1
      cat = Category.last
      expect(current_path).to eq edit_admin_category_path(cat)
      expect(cat.title).to eq "Category test"
    end

    scenario "should be able to delete category" do
      cat = FactoryGirl.create :category

      expect(Category.count).to eq 1
      visit admin_categories_path

      expect(page).to have_content cat.title

      click_link t("delete")

      expect(Category.count).to eq 0
    end
  end

end
