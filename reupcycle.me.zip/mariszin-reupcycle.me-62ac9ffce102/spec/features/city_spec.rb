require 'spec_helper'

feature City do

  context "unauthorised user" do
    scenario "should not be able to see admin menu" do
      visit home_path
      expect(page).not_to have_content t2(City)
    end
  end

  context "user" do
    before :each do
      @user = FactoryGirl.create :user
      login_as @user, scope: :user
    end

    scenario "should not be able to see admin menus" do
      visit home_path
      expect(page).not_to have_content t2(City)
    end
  end

  context "admin" do
    before :each do
      @user = FactoryGirl.create :user, :admin
      login_as @user, scope: :user
    end

    scenario "should be able to see admin menu" do
      visit home_path
      click_link t2(City)
      expect(current_path).to eq admin_cities_path
    end

    scenario "should be able to create city" do
      country = FactoryGirl.create :country

      expect(City.count).to eq 1
      visit admin_cities_path

      click_link t("create")
      select country.name, from: tt(City, :country)
      fill_in tt(City, :name), with: "Sigulda"
      click_button t("save")

      expect(City.count).to eq 2
      city = City.last
      expect(current_path).to eq edit_admin_city_path(city)
      expect(city.name).to eq "Sigulda"
    end

    scenario "should be able to delete city" do
      pending "should research how to select specific city"

      city = FactoryGirl.create :city

      expect(City.count).to eq 1
      visit admin_categories_path

      expect(page).to have_content city.name

      click_link t("delete")

      expect(City.count).to eq 0
    end
  end

end
