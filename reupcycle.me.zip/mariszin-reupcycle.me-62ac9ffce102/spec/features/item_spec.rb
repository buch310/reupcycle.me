require 'spec_helper'

feature Item do

  context "unauthorised user" do
    scenario "should not be able to see items menu" do
      visit home_path
      expect(page).not_to have_content t2(Item)
    end

    context "should see be able to filter items" do
      before :each do
        @swop = FactoryGirl.create :item, :for_swop
        @sale = FactoryGirl.create :item, :for_sale
        @buy  = FactoryGirl.create :item, :for_buy
        @free = FactoryGirl.create :item, :for_free
        visit home_path
      end

      scenario "by nothing" do
        expect(page).to have_content(@swop.title)
        expect(page).to have_content(@sale.title)
        expect(page).to have_content(@buy.title)
        expect(page).to have_content(@free.title)
      end

      scenario "for swop" do
        click_link t("type.swop")
        expect(page).to have_content(@swop.title)
        expect(page).not_to have_content(@sale.title)
        expect(page).not_to have_content(@buy.title)
        expect(page).not_to have_content(@free.title)
      end

      scenario "for sell" do
        click_link t("type.sell")
        expect(page).to have_content(@sale.title)
        expect(page).not_to have_content(@swop.title)
        expect(page).not_to have_content(@buy.title)
        expect(page).not_to have_content(@free.title)
      end

      scenario "for buy" do
        click_link t("type.buy")
        expect(page).to have_content(@buy.title)
        expect(page).not_to have_content(@swop.title)
        expect(page).not_to have_content(@sale.title)
        expect(page).not_to have_content(@free.title)
      end

      scenario "for free" do
        click_link t("type.free")
        expect(page).to have_content(@free.title)
        expect(page).not_to have_content(@swop.title)
        expect(page).not_to have_content(@sale.title)
        expect(page).not_to have_content(@buy.title)
      end
    end
  end

  context "user" do
    before :each do
      @user = FactoryGirl.create :user
      login_as @user, scope: :user
    end

    scenario "should be able to see items menu" do
      visit home_path
      click_link t2(Item)
      expect(current_path).to eq user_items_path
    end

    context "menu" do
      before :each do
        visit user_items_path
      end

      scenario "should not contain any items" do
        expect(Item.count).to eq 0
        expect(page).to have_content t("no_data")
      end

      context "should be able to create a new item" do
        before :each do
          @category = FactoryGirl.create :category, :child
        end

        scenario "for swop", js: true do
          click_link t("create")

          select Item::TYPE_SWOP, from: tt(Item, :item_type)
          fill_in tt(Item, :title), with: "Item test"
          fill_in tt(Item, :description), with: "Description test"
          select @category.title, from: tt(Item, :category)
          fill_in tt(Item, :i_want), with: "some cookies"
          click_button t("save")

          expect(page).to have_content("created")
          expect(Item.count).to eq 1
          item = Item.last
          expect(current_path).to eq edit_user_item_path(item)
        end

        scenario "for sell", js: true do
          click_link t("create")

          select Item::TYPE_SALE, from: tt(Item, :item_type)
          fill_in tt(Item, :title), with: "Item test"
          fill_in tt(Item, :description), with: "Description test"
          select @category.title, from: tt(Item, :category)
          fill_in tt(Item, :price), with: "100"
          click_button t("save")

          expect(page).to have_content("created")
          expect(Item.count).to eq 1
          item = Item.last
          expect(current_path).to eq edit_user_item_path(item)
        end

        scenario "for buy", js: true do
          click_link t("create")

          select Item::TYPE_BUY, from: tt(Item, :item_type)
          fill_in tt(Item, :title), with: "Item test"
          fill_in tt(Item, :description), with: "Description test"
          select @category.title, from: tt(Item, :category)
          # fill_in tt(Item, :price), with: "100"
          click_button t("save")

          expect(page).to have_content("created")
          expect(Item.count).to eq 1
          item = Item.last
          expect(current_path).to eq edit_user_item_path(item)
        end

        scenario "for free", js: true do
          click_link t("create")

          select Item::TYPE_FREE, from: tt(Item, :item_type)
          fill_in tt(Item, :title), with: "Item test"
          fill_in tt(Item, :description), with: "Description test"
          select @category.title, from: tt(Item, :category)
          click_button t("save")

          expect(page).to have_content("created")
          expect(Item.count).to eq 1
          item = Item.last
          expect(current_path).to eq edit_user_item_path(item)
        end
      end
    end

    scenario "should be able to delete item" do
      item = FactoryGirl.create :item, user: @user

      expect(Item.count).to eq 1
      visit user_items_path
      click_link t("delete")

      expect(Item.count).to eq 0
    end
  end
end
