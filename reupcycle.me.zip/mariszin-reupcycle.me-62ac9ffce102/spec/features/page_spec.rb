require 'spec_helper'

feature Page do

  context "unauthorised" do
    scenario "should not be able to see admin menus" do
      visit home_path
      expect(page).not_to have_content t2(Page)
    end

    context "contact us page" do
      scenario "user should see contact us page" do
        visit contact_us_path
        expect(page).to have_content t("pages.contact-us")
      end

      scenario "user should be able to send message" do
        expect(ActionMailer::Base.deliveries.length).to eq 0
        visit contact_us_path
        within ".contact-us" do
          fill_in tt(User, :name), with: "Maris"
          fill_in tt(User, :email), with: "maris@maris.lv"
          fill_in tt(Message, :message), with: "test message"
          click_button t("send-message")
        end

        expect(page).to have_content t("messages.sent")
        expect(ActionMailer::Base.deliveries.length).to eq 1
      end
    end

    scenario "user should see basic text page" do
      p = FactoryGirl.create :page
      visit home_path
      click_link p.title
      expect(page).to have_content p.body
    end
  end

  context "user" do
    before :each do
      @user = FactoryGirl.create :user
      login_as @user, scope: :user
    end

    scenario "should not be able to see admin menus" do
      visit home_path
      expect(page).not_to have_content t2(Page)
    end
  end

  context "admin" do
    before :each do
      @user = FactoryGirl.create :user, :admin
      login_as @user, scope: :user
    end

    scenario "should be able to see admin menu" do
      visit home_path
      click_link t2(Page)
      expect(current_path).to eq admin_pages_path
    end

    scenario "should be able to create page" do
      visit admin_pages_path
      expect(page).to have_content t("no_data")
      expect(Page.count).to eq 0

      click_link t("create")
      fill_in tt(Page, :slug), with: "page-test"
      fill_in tt(Page, :title), with: "Page test"
      fill_in tt(Page, :body), with: "Some body"
      click_button t("save")

      expect(Page.count).to eq 1
      p = Page.last
      expect(current_path).to eq edit_admin_page_path(p)
      expect(p.slug).to eq "page-test"
      expect(p.title).to eq "Page test"
      expect(p.body).to eq "Some body"
    end

    scenario "should be able to delete page" do
      p = FactoryGirl.create :page

      expect(Page.count).to eq 1
      visit admin_pages_path

      expect(page).to have_content p.title

      click_link t("delete")

      expect(Page.count).to eq 0
    end
  end

end
