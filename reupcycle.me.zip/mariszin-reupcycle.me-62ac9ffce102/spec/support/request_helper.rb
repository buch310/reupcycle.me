module RequestHelpers 
  include Warden::Test::Helpers

  def login user
    login_as user, scope: :user
  end

end

RSpec.configure do |config|
  config.include RequestHelpers, type: :feature
end
