require 'ffaker'

FactoryGirl.define do
  factory :city do
    country
    name Faker::Name.name
  end
end
