FactoryGirl.define do
  factory :follower do
    who nil
follows nil
  end

end
