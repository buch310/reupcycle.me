require 'ffaker'

FactoryGirl.define do
  factory :category do
    sequence(:title) { |n| "Category #{n}"}

    trait :child do
      association :parent, factory: :category
    end
  end
end
