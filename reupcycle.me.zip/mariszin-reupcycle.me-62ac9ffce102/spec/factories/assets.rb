include ActionDispatch::TestProcess

FactoryGirl.define do
  factory :asset do
    # item
    image { fixture_file_upload Rails.root.join("spec/fixtures/color.gif") }
  end
end
