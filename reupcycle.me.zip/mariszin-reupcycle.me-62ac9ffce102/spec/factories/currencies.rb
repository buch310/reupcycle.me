# Read about factories at https://github.com/thoughtbot/factory_girl

FactoryGirl.define do
  factory :currency do
    sequence(:name) { |n| "Currency #{n}" }
    sequence(:code) { |n| "C#{n}" }
    sequence(:symbol) { |n| "C#{n}" }
  end
end
