require 'ffaker'

FactoryGirl.define do
  factory :page do
    title { Faker::Lorem.word }
    body { Faker::Lorem.paragraphs }
    slug { Faker::Lorem.word }
  end
end
