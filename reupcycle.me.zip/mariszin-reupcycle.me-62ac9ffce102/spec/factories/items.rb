# Read about factories at https://github.com/thoughtbot/factory_girl

FactoryGirl.define do
  factory :item do
    category
    city
    user
    sequence(:title) { |n| "Item #{n}"}
    description { Faker::Lorem.sentence }
    item_type Item::TYPE_FREE

    trait :for_swop do
      item_type Item::TYPE_SWOP
      open_to_offer true
    end

    trait :for_sale do
      item_type Item::TYPE_SALE
      price 1
    end

    trait :for_buy do
      item_type Item::TYPE_BUY
    end

    trait :for_free do
      item_type Item::TYPE_FREE
    end

    # after :build do |item|
    #   item.assets << FactoryGirl.build(:asset, item: item)
    # end
  end
end
