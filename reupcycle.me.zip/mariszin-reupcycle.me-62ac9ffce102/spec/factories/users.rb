require 'ffaker'

FactoryGirl.define do
  factory :user do
    email { Faker::Internet.email }
    password "123456"
    name { Faker::Name.name }
    city

    trait :admin do
      is_admin true
    end
  end
end
