# Read about factories at https://github.com/thoughtbot/factory_girl

FactoryGirl.define do
  factory :message do
    message { Faker::Lorem.paragraph }
    association :user
    association :receiver, factory: :user
  end
end
