require 'spec_helper'

describe ContactsMailer do

  describe "should send a message to the user" do
    let(:name) { Faker::Name.name }
    let(:mail) { Faker::Internet.email }
    let(:body) { Faker::Lorem.sentence }
    let(:message) { ContactsMailer.contact_us(name, mail, body) }

    it("should set correct subject") { expect(message.subject).to eq t("contact_us.subject", name: name, mail: mail) }
    it("should include message body") { expect(message.body).to have_content body }
  end

end
