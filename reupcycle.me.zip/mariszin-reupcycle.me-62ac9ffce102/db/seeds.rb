# encoding: utf-8

lv = Country.find_by_code("LV")
riga = City.find_by_name("Rīga")

# admin = User.create!(:email => "info@swop-me.com", :password => "swopme", :name => "Admin", city: riga, country: lv)
admin = User.find_by_email("info@swop-me.com")
admin.update_attribute :is_admin, true

user = User.create!(:email => "test@swop-me.com", :password => "123456", :name => "Test user", city: riga, country: lv)
user.save!
