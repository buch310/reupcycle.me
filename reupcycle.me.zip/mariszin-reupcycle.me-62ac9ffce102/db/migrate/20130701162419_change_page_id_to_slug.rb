class ChangePageIdToSlug < ActiveRecord::Migration
  def up
    add_column :pages, :slug, :string
    add_index  :pages, :slug

    Page.reset_column_information

    Page.find_each do |p|
      p.slug = Page::PAGE_TYPE_STR[p.page_id]
      p.save!
    end

    remove_column :pages, :page_id
  end

  def down
  end
end
