class CreateItemMessages < ActiveRecord::Migration
  def change
    create_table :item_messages do |t|
      t.integer :offer_id
      t.integer :from_id
      t.integer :to_id
      t.text :message
      t.boolean :read, default: false
      t.boolean :active, default: true

      t.timestamps null: false
    end
  end
end
