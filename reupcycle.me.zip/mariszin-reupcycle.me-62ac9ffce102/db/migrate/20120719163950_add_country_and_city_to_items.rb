class AddCountryAndCityToItems < ActiveRecord::Migration
  def change
    add_column :items, :country_id, :integer
    add_column :items, :city_id, :integer
  end
end
