class CreateTranslationTables < ActiveRecord::Migration
  def up
    Category.create_translation_table!({:title => :string, :description => :text}, {:migrate_data => true})
    execute <<-SQL
    insert into category_translations (category_id,locale, description, title, created_at, updated_at) select category_id,'lv', description, title, created_at, updated_at from category_translations where locale='en';
    SQL
    City.create_translation_table!({:name => :string}, {:migrate_data => true})
    execute <<-SQL
    insert into city_translations (city_id,locale, name, created_at, updated_at) select city_id,'lv', name, created_at, updated_at from city_translations where locale='en';
    SQL
    Country.create_translation_table!({:name => :string}, {:migrate_data => true})
    execute <<-SQL
    insert into country_translations (country_id,locale, name, created_at, updated_at) select country_id,'lv', name, created_at, updated_at from country_translations where locale='en';
    SQL
    Currency.create_translation_table!({:name => :string}, {:migrate_data => true})
    execute <<-SQL
    insert into currency_translations (currency_id,locale, name, created_at, updated_at) select currency_id,'lv', name, created_at, updated_at from currency_translations where locale='en';
    SQL
    Page.create_translation_table!({:title => :string, :body => :text}, {:migrate_data => true})
    execute <<-SQL
    insert into page_translations (page_id,locale, body, title, created_at, updated_at) select page_id,'lv', body, title, created_at, updated_at from page_translations where locale='en';
    SQL
  end

  def down
    Category.drop_translation_table! :migrate_data => true
    City.drop_translation_table! :migrate_data => true
    Country.drop_translation_table! :migrate_data => true
    Currency.drop_translation_table! :migrate_data => true
    Page.drop_translation_table! :migrate_data => true
  end
end
