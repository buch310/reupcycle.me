class AddLftRgtDepthToCategories < ActiveRecord::Migration
  def change
  end
end
