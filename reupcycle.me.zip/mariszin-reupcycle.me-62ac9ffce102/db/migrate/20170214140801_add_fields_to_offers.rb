class AddFieldsToOffers < ActiveRecord::Migration
  def change
  	add_column :offers, :owner_swap_pending, :boolean, default: false
  	add_column :offers, :offerer_swap_pending, :boolean, default: false
  end
end
