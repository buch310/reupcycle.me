class ChangePriceOnItems < ActiveRecord::Migration
  def up
    remove_column :items, :price
    add_column :items, :price, :string
  end

  def up
    remove_column :items, :price
    add_column :items, :price, :decimal, :precision => 8, :scale => 2, :default => 0.0
  end
end
