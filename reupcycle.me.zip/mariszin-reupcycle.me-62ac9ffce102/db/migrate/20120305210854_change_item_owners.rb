class ChangeItemOwners < ActiveRecord::Migration
  def up
    Offer.where(:offerer_received => true, :owner_received => true).each do |offer|
      owner_id = offer.owner_id
      offerer_id = offer.offerer_id
      offer.item.update_attribute :user_id, offerer_id
      offer.offered.update_attribute :user_id, owner_id
      offer.delete
    end
  end

  def down
  end
end
