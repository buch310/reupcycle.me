class AddShowLocationToItems < ActiveRecord::Migration
  def change
    add_column :items, :show_location, :boolean, default: true
  end
end
