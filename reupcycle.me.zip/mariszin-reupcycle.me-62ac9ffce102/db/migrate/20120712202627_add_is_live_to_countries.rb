class AddIsLiveToCountries < ActiveRecord::Migration
  def change
    add_column :countries, :is_live, :boolean, :default => false
  end
end
