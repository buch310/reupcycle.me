class SetDefaultCurrencies < ActiveRecord::Migration
  def up
    currency = Currency.find_by_code("GBP")
    Item.where(:currency_id => nil).each {|i| i.update_attribute :currency_id, currency }
  end

  def down
  end
end
