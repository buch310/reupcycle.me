class ChangeValidUntilType < ActiveRecord::Migration
  def up
    add_column :items, :valid_until_new, :date
    execute "UPDATE items set valid_until_new = valid_until"
    remove_column :items, :valid_until
    rename_column :items, :valid_until_new, :valid_until
  end

  def down
  end
end
