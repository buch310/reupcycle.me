class UpdateCityInItems < ActiveRecord::Migration
  def up
    Item.find_each do |i|
      if i.city_id
        i.city = City.find(i.city_id).name
        i.save!
      end
    end
  end

  def down
  end
end
