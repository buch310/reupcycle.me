class AddFieldToOffer < ActiveRecord::Migration
  def change
    add_column :offers, :swap_id, :integer
    add_column :offers, :owner_pending, :boolean
  end
end
