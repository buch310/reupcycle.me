class FillInCategories < ActiveRecord::Migration
  class Category < ActiveRecord::Base
    acts_as_nested_set
  end
  def up
    electronics = Category.create(:title => "Electronics", :visible => true)
    electronics.children.create(:title => "Cameras & Photography", :visible => true)
    electronics.children.create(:title => "Computers, Tablets & Networking", :visible => true)
    electronics.children.create(:title => "Mobile & Home Phones", :visible => true)
    electronics.children.create(:title => "More Electronics", :visible => true)
    electronics.children.create(:title => "TV, Video & Audio", :visible => true)
    electronics.children.create(:title => "Video Games & Consoles", :visible => true)

    fashion = Category.create(:title => "Fashion", :visible => true)
    fashion.children.create(:title => "Women's Clothing", :visible => true)
    fashion.children.create(:title => "Women's Handbags", :visible => true)
    fashion.children.create(:title => "Women's Shoes", :visible => true)
    fashion.children.create(:title => "Men's Clothing", :visible => true)
    fashion.children.create(:title => "Men's Shoes", :visible => true)

    homegarden = Category.create(:title => "Home & Garden", :visible => true)
    homegarden.children.create(:title => "Baby", :visible => true)
    homegarden.children.create(:title => "Crafts", :visible => true)
    homegarden.children.create(:title => "Home & Garden", :visible => true)
    homegarden.children.create(:title => "Property", :visible => false)

    sports = Category.create(:title => "Sports & Leisure", :visible => true)
    sports.children.create(:title => "Events Tickets", :visible => true)
    sports.children.create(:title => "Holiday & Travel", :visible => true)
    sports.children.create(:title => "Musical Instruments", :visible => true)
    sports.children.create(:title => "Sporting Goods", :visible => true)
    sports.children.create(:title => "Toys & Games", :visible => true)

    books = Category.create(:title => "Books, Films & Music", :visible => true)
    books.children.create(:title => "Books, Comics & Magazines", :visible => true)
    books.children.create(:title => "DVD, Film & TV", :visible => false)
    books.children.create(:title => "Music", :visible => false)

    collectables = Category.create(:title => "Collectables", :visible => true)
    collectables.children.create(:title => "Antiques", :visible => true)
    collectables.children.create(:title => "Art", :visible => true)
    collectables.children.create(:title => "Coins", :visible => true)
    collectables.children.create(:title => "Collectables", :visible => true)
    collectables.children.create(:title => "Dolls & Bears", :visible => true)
    collectables.children.create(:title => "Pottery, Porcelain & Glass", :visible => true)
    collectables.children.create(:title => "Sports Memorabilia", :visible => true)
    collectables.children.create(:title => "Stamps", :visible => true)
  end

  def down
    Category.delete_all
  end
end
