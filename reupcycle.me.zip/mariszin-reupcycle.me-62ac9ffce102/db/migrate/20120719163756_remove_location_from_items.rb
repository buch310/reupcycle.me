class RemoveLocationFromItems < ActiveRecord::Migration
  def up
    remove_column :items, :location_parent_id
    remove_column :items, :location_child_id
  end

  def down
    add_column :items, :location_child_id, :integer
    add_column :items, :location_parent_id, :integer
  end
end
