class ChangeOfferedIdInOffers < ActiveRecord::Migration
  def up
    change_column :offers, :offered_id, :integer, :null => true
  end

  def down
    change_column :offers, :offered_id, :integer, :null => false
  end
end
