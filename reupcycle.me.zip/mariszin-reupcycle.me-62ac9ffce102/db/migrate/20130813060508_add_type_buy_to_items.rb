class AddTypeBuyToItems < ActiveRecord::Migration
  def change
    execute "update items set item_type=3 where item_type=2"
  end
end
