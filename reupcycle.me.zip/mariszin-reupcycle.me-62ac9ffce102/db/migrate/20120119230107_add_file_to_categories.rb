class AddFileToCategories < ActiveRecord::Migration
  def change
    add_column :categories, :image_file_name, :string
    add_column :categories, :image_content_type, :string
    add_column :categories, :image_file_size, :integer
  end
end
