class RenameCategoryImage < ActiveRecord::Migration
  def change
    rename_column :categories, :image_file_name, :placeholder_file_name
    rename_column :categories, :image_content_type, :placeholder_content_type
    rename_column :categories, :image_file_size, :placeholder_file_size
  end

end
