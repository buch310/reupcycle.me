class AddLocationsToItems < ActiveRecord::Migration
  def change
    add_column :items, :location_parent_id, :integer
    add_column :items, :location_child_id, :integer
  end
end
