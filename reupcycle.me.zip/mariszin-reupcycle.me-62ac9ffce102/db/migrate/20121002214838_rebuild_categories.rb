class RebuildCategories < ActiveRecord::Migration
  class Category < ActiveRecord::Base
    acts_as_nested_set
  end

  def up
    Category.rebuild!
  end

  def down
  end
end
