class AddUserHasReadToOffers < ActiveRecord::Migration
  def change
    add_column :offers, :user_has_read, :boolean, :default => false
  end
end
