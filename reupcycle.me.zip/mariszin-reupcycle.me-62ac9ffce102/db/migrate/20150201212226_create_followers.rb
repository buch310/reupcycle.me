class CreateFollowers < ActiveRecord::Migration
  def change
    create_table :followers do |t|
      t.references :who, index: true
      t.references :follow, index: true

      t.timestamps
    end
  end
end
