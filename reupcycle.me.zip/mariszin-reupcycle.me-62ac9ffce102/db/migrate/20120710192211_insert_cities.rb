# encoding: utf-8
class InsertCities < ActiveRecord::Migration
  class Country < ActiveRecord::Base
  end
  class City < ActiveRecord::Base
  end

  def up
    uk = Country.find_by_code("UK")
    lv = Country.find_by_code("LV")

    City.create!(:name => "Nav sarakstā", :country_id => lv.id)
    City.create!(:name => "Rīga", :country_id => lv.id)
    City.create!(:name => "Tukums", :country_id => lv.id)
    City.create!(:name => "Cēsis", :country_id => lv.id)
    City.create!(:name => "Valmiera", :country_id => lv.id)
    City.create!(:name => "Sigulda", :country_id => lv.id)
    City.create!(:name => "Madona", :country_id => lv.id)
    City.create!(:name => "Liepāja", :country_id => lv.id)
    City.create!(:name => "Ventspils", :country_id => lv.id)
    City.create!(:name => "Daugavpils", :country_id => lv.id)

    City.create!(:name => "Not listed", :country_id => uk.id)
    City.create!(:name => "London", :country_id => uk.id)
  end

  def down
    City.delete_all
  end
end
