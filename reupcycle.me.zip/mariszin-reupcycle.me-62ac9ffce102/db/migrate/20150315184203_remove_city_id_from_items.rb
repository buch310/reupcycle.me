class RemoveCityIdFromItems < ActiveRecord::Migration
  def change
    remove_column :items, :city_id
  end
end
