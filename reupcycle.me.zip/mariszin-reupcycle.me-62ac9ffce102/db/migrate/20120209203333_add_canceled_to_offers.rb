class AddCanceledToOffers < ActiveRecord::Migration
  def change
    add_column :offers, :canceled, :boolean, :default => false
    add_column :offers, :canceled_by_id, :integer, :default => nil
  end
end
