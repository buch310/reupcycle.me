class AddUserHasReadToMessages < ActiveRecord::Migration
  def change
    add_column :messages, :user_has_read, :boolean, :default => false
  end
end
