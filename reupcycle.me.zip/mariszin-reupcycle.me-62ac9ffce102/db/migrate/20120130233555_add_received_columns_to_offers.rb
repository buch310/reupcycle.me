class AddReceivedColumnsToOffers < ActiveRecord::Migration
  def change
    add_column :offers, :owner_received, :boolean, :default => false
    add_column :offers, :offerer_received, :boolean, :default => false
  end
end
