class FixTranslationsBase < ActiveRecord::Migration
  def change
    Category::Translation.destroy_all
    Category.find_each do |c|
      I18n.available_locales.each do |l|
        Category::Translation.create(
          locale: l.to_s,
          category_id: c.id,
          title: c.title,
          description: c.description
        )
      end
    end


    Page::Translation.destroy_all
    Page.find_each do |p|
      I18n.available_locales.each do |l|
        Page::Translation.create(
          locale: l.to_s,
          page_id: p.id,
          title: p.title,
          body: p.body
        )
      end
    end
  end
end
