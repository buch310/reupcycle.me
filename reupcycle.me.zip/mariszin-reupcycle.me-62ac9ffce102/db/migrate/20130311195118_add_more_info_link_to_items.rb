class AddMoreInfoLinkToItems < ActiveRecord::Migration
  def change
    add_column :items, :more_info_link, :string
    add_column :items, :more_info_local, :boolean, :default => true
  end
end
