class InsertCountries < ActiveRecord::Migration
  class Country < ActiveRecord::Base
  end

  def up
    Country.create!(:code => "LV", :name => "Latvija")
    Country.create!(:code => "UK", :name => "United Kingdom")
  end

  def down
    Country.delete_all
  end
end
