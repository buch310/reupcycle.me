class CreateDefaultPages < ActiveRecord::Migration
  class Page < ActiveRecord::Base
    PAGE_ABOUT = 1
    PAGE_PRIVACY = 2
    PAGE_TERMS = 3

    PAGE_TYPE_INT = {
      "about-us" => PAGE_ABOUT,
      "privacy-policy" => PAGE_PRIVACY,
      "terms-of-use" => PAGE_TERMS
    }

    PAGE_TYPE_STR = {
      PAGE_ABOUT => "about-us",
      PAGE_PRIVACY => "privacy-policy",
      PAGE_TERMS => "terms-of-use"
    }
  end
  def up
    Page.create(:page_id => Page::PAGE_ABOUT, :title => "About Us", :body => "About Swop-Me.com")
    Page.create(:page_id => Page::PAGE_PRIVACY, :title => "Privacy Policy", :body => "Privacy Policy")
    Page.create(:page_id => Page::PAGE_TERMS, :title => "Terms Of Use", :body => "Terms Of Use")
  end

  def down
    Page.delete_all
  end
end
