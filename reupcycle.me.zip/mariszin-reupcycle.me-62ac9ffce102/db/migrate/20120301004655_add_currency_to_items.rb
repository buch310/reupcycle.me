class AddCurrencyToItems < ActiveRecord::Migration
  def change
    add_column :items, :currency_id, :integer
  end
end
