class ChangeItemTypeToString < ActiveRecord::Migration
  def up
    add_column :items, :item_type_new, :string, default: "swop"
    execute 'update items set item_type_new="swop" where item_type=0'
    execute 'update items set item_type_new="sell" where item_type=1'
    execute 'update items set item_type_new="free" where item_type=3'
    remove_column :items, :item_type
    rename_column :items, :item_type_new, :item_type
    add_index :items, :item_type
  end

  def down
  end
end
