class CreateOffers < ActiveRecord::Migration
  def change
    create_table :offers do |t|
      t.integer :owner_id, :null => false
      t.integer :offerer_id, :null => false
      t.integer :item_id, :null => false
      t.integer :offered_id, :null => false
      t.boolean :accepted, :default => false

      t.timestamps
    end
  end
end
