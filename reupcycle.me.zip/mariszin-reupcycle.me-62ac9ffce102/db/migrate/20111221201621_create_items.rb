class CreateItems < ActiveRecord::Migration
  def change
    create_table :items do |t|
      t.integer :user_id, :null => false 
      t.integer :category_id
      t.string :title, :null => false
      t.text :description, :null => false
      t.boolean :open_to_offer, :default => false
      t.string :i_want
      t.string :location_text
      t.decimal :lat, :precision => 15, :scale => 10
      t.decimal :lng, :precision => 15, :scale => 10
      t.datetime :valid_until, :null => false
      t.boolean :active, :default => true

      t.timestamps
    end
  end
end
