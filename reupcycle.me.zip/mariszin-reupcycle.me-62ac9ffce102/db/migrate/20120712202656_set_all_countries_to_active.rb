class SetAllCountriesToActive < ActiveRecord::Migration
  class Country < ActiveRecord::Base
  end

  def up
    Country.find_each do |c|
      c.update_attribute :is_live, true
    end
  end

  def down
    Country.find_each do |c|
      c.update_attribute :is_live, false
    end
  end
end
