class GenerateSlugsForCategories < ActiveRecord::Migration
  def up
    Category.find_each(&:save)
  end

  def down
  end
end
