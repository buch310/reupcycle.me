class CreateNotifications < ActiveRecord::Migration
  def change
    create_table :notifications do |t|
      t.integer :from_id
      t.integer :to_id
      t.integer :attachable_id
      t.string :attachable_type
      t.boolean :read, default: false

      t.timestamps null: false
    end
  end
end
