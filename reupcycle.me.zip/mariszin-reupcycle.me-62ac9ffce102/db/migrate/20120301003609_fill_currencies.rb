# encoding: utf-8
class FillCurrencies < ActiveRecord::Migration
  class Currency < ActiveRecord::Base
  end
  def up
    Currency.create!(:code => "GBP", :name => "Pounds", :symbol => "£")
    Currency.create!(:code => "EUR", :name => "Euros", :symbol => "€")
  end

  def down
    Currency.delete_all
  end
end
