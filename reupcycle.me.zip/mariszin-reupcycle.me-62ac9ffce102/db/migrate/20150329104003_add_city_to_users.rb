class AddCityToUsers < ActiveRecord::Migration
  def up
    add_column :users, :city, :string
    User.find_each do |i|
      if i.city_id
        i.city = City.find(i.city_id).name
        i.save!
      end
    end
    remove_column :users, :city_id
  end
end
