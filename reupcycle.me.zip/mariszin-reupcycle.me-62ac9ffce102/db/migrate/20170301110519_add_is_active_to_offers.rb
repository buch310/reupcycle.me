class AddIsActiveToOffers < ActiveRecord::Migration
  def change
    add_column :offers, :is_active, :boolean, :default => true
    add_column :offers, :is_offerer_completed, :boolean, :default => true
    add_column :offers, :is_owner_completed, :boolean, :default => true
  end
end
