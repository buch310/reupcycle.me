class ChangeAssetAssociation < ActiveRecord::Migration
  def change
    rename_column :assets, :item_id, :object_id
    add_column :assets, :object_type, :string
    Asset.update_all(object_type: "Item")
    add_index :assets, [:object_id, :object_type]
  end
end
