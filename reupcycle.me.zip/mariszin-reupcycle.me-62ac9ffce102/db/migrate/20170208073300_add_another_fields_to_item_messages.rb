class AddAnotherFieldsToItemMessages < ActiveRecord::Migration
  def change
    add_column :item_messages, :deleted_by_owner, :boolean, default: false
    add_column :item_messages, :deleted_by_offerer, :boolean, default: false
  end
end
